#pragma once

#include "lemma.h"
#include "form.h"
