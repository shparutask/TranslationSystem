#include "wordspair.h"


CWordsPair* CWordsPair::CloneAsWordsPair()
{
    ythrow yexception() << " \"CWordsPair::CloneAsWordsPair\" must be o";
}

