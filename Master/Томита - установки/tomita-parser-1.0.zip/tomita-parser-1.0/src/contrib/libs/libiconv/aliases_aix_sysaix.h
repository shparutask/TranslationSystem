/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

S(aix_0, "CP856", ei_cp856 )
  S(aix_1, "IBM-856", ei_cp856 )
  S(aix_2, "CP922", ei_cp922 )
  S(aix_3, "IBM-922", ei_cp922 )
  S(aix_4, "CP943", ei_cp943 )
  S(aix_5, "IBM-943", ei_cp943 )
  S(aix_6, "CP1046", ei_cp1046 )
  S(aix_7, "IBM-1046", ei_cp1046 )
  S(aix_8, "CP1124", ei_cp1124 )
  S(aix_9, "IBM-1124", ei_cp1124 )
  S(aix_10, "CP1129", ei_cp1129 )
  S(aix_11, "IBM-1129", ei_cp1129 )
  S(aix_12, "CP1161", ei_cp1161 )
  S(aix_13, "IBM1161", ei_cp1161 )
  S(aix_14, "IBM-1161", ei_cp1161 )
  S(aix_15, "CSIBM1161", ei_cp1161 )
  S(aix_16, "CP1162", ei_cp1162 )
  S(aix_17, "IBM1162", ei_cp1162 )
  S(aix_18, "IBM-1162", ei_cp1162 )
  S(aix_19, "CSIBM1162", ei_cp1162 )
  S(aix_20, "CP1163", ei_cp1163 )
  S(aix_21, "IBM1163", ei_cp1163 )
  S(aix_22, "IBM-1163", ei_cp1163 )
  S(aix_23, "CSIBM1163", ei_cp1163 )
