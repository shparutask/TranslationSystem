/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

(int)(long)&((struct stringpool_t *)0)->stringpool_str275,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str465,
