/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

(int)(long)&((struct stringpool2_t *)0)->stringpool_aix_0,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_2,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_4,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_6,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_8,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_10,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_12,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_16,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_aix_20,
