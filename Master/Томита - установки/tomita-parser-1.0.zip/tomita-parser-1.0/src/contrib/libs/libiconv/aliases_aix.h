/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

S(aix_0, "CP856", ei_cp856 )
  S(aix_1, "CP922", ei_cp922 )
  S(aix_2, "CP943", ei_cp943 )
  S(aix_3, "CP1046", ei_cp1046 )
  S(aix_4, "CP1124", ei_cp1124 )
  S(aix_5, "CP1129", ei_cp1129 )
  S(aix_6, "CP1161", ei_cp1161 )
  S(aix_7, "IBM1161", ei_cp1161 )
  S(aix_8, "IBM-1161", ei_cp1161 )
  S(aix_9, "CSIBM1161", ei_cp1161 )
  S(aix_10, "CP1162", ei_cp1162 )
  S(aix_11, "IBM1162", ei_cp1162 )
  S(aix_12, "IBM-1162", ei_cp1162 )
  S(aix_13, "CSIBM1162", ei_cp1162 )
  S(aix_14, "CP1163", ei_cp1163 )
  S(aix_15, "IBM1163", ei_cp1163 )
  S(aix_16, "IBM-1163", ei_cp1163 )
  S(aix_17, "CSIBM1163", ei_cp1163 )
